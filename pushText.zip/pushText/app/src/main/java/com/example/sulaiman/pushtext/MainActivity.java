package com.example.sulaiman.pushtext;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.firebase.client.Firebase;

public class MainActivity extends AppCompatActivity {
    private Button mSend;
    private EditText mText;
    private Firebase mRoot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRoot = new Firebase("https://pushtext-5a6c7.firebaseio.com/user");
        mSend = (Button) findViewById(R.id.button);
        mText = (EditText) findViewById(R.id.text);


        mSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value = mText.getText().toString();
               //Firebase childRef = mRoot.child("Name");
                mRoot.push().setValue(value);

            }
        });


    }
}
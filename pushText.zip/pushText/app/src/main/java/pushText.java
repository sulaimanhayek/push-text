import android.app.Application;

import com.firebase.client.Firebase;

/**
 * Created by lost on 16/06/2018.
 */

public class pushText extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Firebase.setAndroidContext(this);

    }
}
